package restaurantsoftware;

import java.io.IOException;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import static restaurantsoftware.DBConnector.stmt;
/**
 * FXML Controller class
 *
 * @author kiran_000
 */
public class EditMenuController1 implements Initializable {

    @FXML
    private Button addButton1;
    @FXML
    private Button editButton1;
    @FXML
    private Button updateButton1;
    @FXML
    private Button deleteButton1;
    @FXML
    private Button clearButton1;
    @FXML
    private Button addButton2;
    @FXML
    private Button editButton2;
    @FXML
    private Button updateButton2;
    @FXML
    private Button deleteButton2;
    @FXML
    private Button clearButton2;
   
    
    @FXML
    private TableView<ModelTable> EntreeTable;
    
    
    @FXML
    private TableColumn<ModelTable, String> EPrice;
    
    @FXML
    private TableColumn<ModelTable, String> EItem;
    
    @FXML
   private TableColumn<ModelTable, String> EId;
    @FXML
    private TableColumn<ModelTable, String> ETime;
   
    
    @FXML
    private TableView<ModelTable> MainTable;
    @FXML
    private TableColumn<ModelTable, String> MItem;
    @FXML
    private TableColumn<ModelTable, String> MPrice;
     @FXML
    private TableColumn<ModelTable, String> MId;
    @FXML
    private TableColumn<ModelTable, String> MTime;
    
    
    
    @FXML
    private TableView<ModelTable> DessertTable;
    @FXML
    private TableColumn<ModelTable, String> DItem;
    @FXML
    private TableColumn<ModelTable, String> DPrice;
    @FXML
    private TableColumn<ModelTable, String> DId;
    @FXML
    private TableColumn<ModelTable, String> DTime;
    
   
    
     
    @FXML
    private Button deleteButton3;
    
    @FXML
    private Button addButton3;
    @FXML
    private Button editButton3;
    @FXML
    private Button updateButton3;
    @FXML
    private Button clearButton3;
    @FXML
    private TextField EntreePriceField;
    @FXML
    private TextField EntreeNameField;
    
    @FXML
    private TextField MainPriceField;
    @FXML
    private TextField DessertPriceField;
    
    
    
    ObservableList<ModelTable> oblist = FXCollections.observableArrayList();
    ObservableList<ModelTable> oblist1 = FXCollections.observableArrayList();
    ObservableList<ModelTable> oblist2 = FXCollections.observableArrayList();
    
     @FXML
    private TextField MainNameField;
    @FXML
    private TextField DessertNameField;
   
    @FXML
    private TextField MainTimeField;
    

    @FXML
    private TextField DessertTimeField;
    @FXML
    private Button backButton;
  
    @FXML
    private TextField EntreeTimeField;
    @FXML private TextField EntreeIDField;
    @FXML private TextField DessertIDField;
    
    @FXML
            private TextField MainIDField;
    
    Connection connection;
    
    
    //tray notification variables
    String focus = "ITEM DATA";
    String detail;
   MessageNotification messageNotification = new MessageNotification();
   
    Random rand = new Random();
    int x = rand.nextInt(10000);
    public String xx = Integer.toString(x);
    @FXML
    private Button exit;

    
   public EditMenuController1() {
    } 
   
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try{
        Connection con = DBConnector.getConnection();
            ResultSet rs = con.createStatement().executeQuery("select * from entree");
            ResultSet rs1 = con.createStatement().executeQuery("select * from main");
            ResultSet rs2 = con.createStatement().executeQuery("select * from dessert");
            
            
           while (rs.next()){
                oblist.add(new ModelTable(rs.getLong("ID"),rs.getString("item_name"),rs.getDouble("price"),rs.getInt("time_req")));
            }
            while (rs1.next()){
                oblist1.add(new ModelTable(rs1.getLong("ID"),rs1.getString("item_name"),rs1.getDouble("price"),rs1.getInt("time_req")));
            }
            while (rs2.next()){
                oblist2.add(new ModelTable(rs2.getLong("ID"),rs2.getString("item_name"),rs2.getDouble("price"),rs2.getInt("time_req")));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //EItem.setCellValueFactory(new PropertyValueFactory<>("ID"));
        EItem.setCellValueFactory(new PropertyValueFactory<>("item"));
        EPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        EId.setCellValueFactory(new PropertyValueFactory<>("id"));
        ETime.setCellValueFactory(new PropertyValueFactory<>("time"));
        
        
        MItem.setCellValueFactory(new PropertyValueFactory<>("item"));
        MPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        MId.setCellValueFactory(new PropertyValueFactory<>("id"));
        MTime.setCellValueFactory(new PropertyValueFactory<>("time"));
         
        
        
         DItem.setCellValueFactory(new PropertyValueFactory<>("item"));
        DPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        DId.setCellValueFactory(new PropertyValueFactory<>("id"));
        DTime.setCellValueFactory(new PropertyValueFactory<>("time"));
        
        
        
        
        EntreeTable.setItems(oblist);
        MainTable.setItems(oblist1);
        DessertTable.setItems(oblist2);    
    }    

    
    
    @FXML
    public void addEntree(ActionEvent event) throws SQLException, ClassNotFoundException {
       int lastIDEntree = 0; 
       try{
       
         Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
            stmt=connection.createStatement();
            stmt.execute("INSERT INTO entree (ITEM_NAME,PRICE,time_req)VALUES ('"+EntreeNameField.getText()+"','"+EntreePriceField.getText()+"','"+EntreeTimeField.getText()+"')");
             
            ResultSet rs2 = connection.createStatement().executeQuery("select ID from entree ORDER BY ID DESC LIMIT 1");
              while(rs2.next()){
                 lastIDEntree = rs2.getInt(1);
             }
             EntreeIDField.setText(String.valueOf(lastIDEntree));
            
            oblist.add(new ModelTable(Long.parseLong(EntreeIDField.getText()),EntreeNameField.getText(), Double.parseDouble(EntreePriceField.getText()),Integer.parseInt(EntreeTimeField.getText())));
      //EntreeIDField.setText(new Date().getTime() + "");
             stmt.close(); 
            JOptionPane.showMessageDialog(null, "ADDED");
            clearEntree();
           
          //  messageNotification.addSuccessTrayNotification(focus,detail);
              
        //String query = new String("INSERT INTO entree (id,ITEM_NAME,PRICE,time_req)VALUES ('"+EntreeIDField.getText()+"','"+EntreeNameField.getText()+"','"+EntreePriceField.getText()+",'"+EntreeTimeField.getText()+"'')");
     //stmt.executeUpdate(query);
     //DBConnector.getConnection();
      //DBConnector.write(query);
       } catch (SQLException ex) {
          //  Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Invalid Input. The menu item was not added");
            messageNotification.addErrorTrayNotification(focus);
            
            
        } 
    } 
          
    @FXML
    public void addMain(ActionEvent event) throws SQLException, ClassNotFoundException {   
        int lastIDMain = 0;
         
       try{
        //Connection con = DBConnector.getConnection();
         Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
            stmt=connection.createStatement();
             stmt.execute("INSERT INTO main (item_name,price,time_req)VALUES ('"+MainNameField.getText()+"','"+MainPriceField.getText()+"','"+MainTimeField.getText()+"')");
             ResultSet rs = connection.createStatement().executeQuery("select ID from main ORDER BY ID DESC LIMIT 1");
              while(rs.next()){
                 lastIDMain = rs.getInt(1);
             }
             MainIDField.setText(String.valueOf(lastIDMain)); 
             oblist1.add(new ModelTable(Long.parseLong(MainIDField.getText()),MainNameField.getText(), Double.parseDouble(MainPriceField.getText()),Integer.parseInt(MainTimeField.getText())));
     // MainIdField.setText(xx);
//     MainIdField.setText(new Date().getTime() + "");
             stmt.close();
              messageNotification.addSuccessTrayNotification(focus, detail);
              JOptionPane.showMessageDialog(null, "Added ");
              
             clearMain();
             
         } catch (SQLException ex) {
          //  Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            
            JOptionPane.showMessageDialog(null, "Invalid Input. The menu item was not added");
            messageNotification.addErrorTrayNotification(focus);
        } 
    } 
          
    @FXML
    public void addDessert(ActionEvent event) throws SQLException, ClassNotFoundException { 
        int lastIDDessert = 0;
       try{
        //Connection con = DBConnector.getConnection();
         Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
            stmt=connection.createStatement();
             stmt.execute("INSERT INTO dessert (item_name,price,time_req)VALUES ('"+DessertNameField.getText()+"','"+DessertPriceField.getText()+"','"+DessertTimeField.getText()+"')");
             
             ResultSet rs1 = connection.createStatement().executeQuery("select ID from dessert ORDER BY ID DESC LIMIT 1");
              while(rs1.next()){
                 lastIDDessert = rs1.getInt(1);
             }
             DessertIDField.setText(String.valueOf(lastIDDessert));
             
             oblist2.add(new ModelTable(Long.parseLong(DessertIDField.getText()),DessertNameField.getText(), Double.parseDouble(DessertPriceField.getText()),Integer.parseInt(DessertTimeField.getText())));
//       DessertIdField.setText(new Date().getTime() + "");
             //DessertIdField.setText(xx);
             stmt.close();
              messageNotification.addSuccessTrayNotification(focus, detail);
              JOptionPane.showMessageDialog(null, "Added ");
              clearDessert();
         } catch (SQLException ex) {
           // Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Invalid Input. The menu item was not added");
            messageNotification.addErrorTrayNotification(focus);
            //JOptionPane.showMessageDialog(null, "You cannot enter same ID ");
        } 
    }          
          
          
    

    
    
    //populate gui fields based on user selection of table row
    @FXML
    private void editEntree(ActionEvent event) {
        
        
        
         
        if (EntreeTable.getSelectionModel().isEmpty()) {
            //select last row
            EntreeTable.getSelectionModel().selectLast();
        }

        //fill up gui text fields via table selection of user
        
        
        EntreeNameField.setText(EntreeTable.getItems().get(EntreeTable.getSelectionModel().getSelectedIndex()).getItem());
        EntreePriceField.setText(EntreeTable.getItems().get(EntreeTable.getSelectionModel().getSelectedIndex()).getPrice().toString());
       EntreeIDField.setText(EntreeTable.getItems().get(EntreeTable.getSelectionModel().getSelectedIndex()).getId().toString());
        EntreeTimeField.setText(EntreeTable.getItems().get(EntreeTable.getSelectionModel().getSelectedIndex()).getTime().toString());
   
        //enable button
        updateButton1.setDisable(false);

        //disable button
        addButton1.setDisable(true);
        deleteButton1.setDisable(true);
        resetFields();
                 
    }         
         
    @FXML
    private void editMain(ActionEvent event){
       
        if (MainTable.getSelectionModel().isEmpty()) {
            //select last row
            MainTable.getSelectionModel().selectLast();
        }

        //fill up gui text fields via table selection of user
        
        MainNameField.setText(MainTable.getItems().get(MainTable.getSelectionModel().getSelectedIndex()).getItem());
        MainPriceField.setText(MainTable.getItems().get(MainTable.getSelectionModel().getSelectedIndex()).getPrice().toString());
         MainIDField.setText(MainTable.getItems().get(MainTable.getSelectionModel().getSelectedIndex()).getId().toString());
        MainTimeField.setText(MainTable.getItems().get(MainTable.getSelectionModel().getSelectedIndex()).getTime().toString());
   

        //enable button
        updateButton2.setDisable(false);

        //disable button
        addButton2.setDisable(true);
        deleteButton2.setDisable(true);
        resetFields();
                 
    }
    
    @FXML
    private void editDessert(ActionEvent event){
        
        
        if (DessertTable.getSelectionModel().isEmpty()) {
            //select last row
            DessertTable.getSelectionModel().selectLast();
        }

        DessertNameField.setText(DessertTable.getItems().get(DessertTable.getSelectionModel().getSelectedIndex()).getItem());
        DessertPriceField.setText(DessertTable.getItems().get(DessertTable.getSelectionModel().getSelectedIndex()).getPrice().toString());
        DessertIDField.setText(DessertTable.getItems().get(DessertTable.getSelectionModel().getSelectedIndex()).getId().toString());
        DessertTimeField.setText(DessertTable.getItems().get(DessertTable.getSelectionModel().getSelectedIndex()).getTime().toString());
   

        //enable button
        updateButton3.setDisable(false);

        //disable button
        addButton3.setDisable(true);
        deleteButton3.setDisable(true);
        resetFields();
                 
         
    }

    //Delete an sales data with a given sales Id from DB
    @FXML
    public void deleteEntree(ActionEvent event) throws SQLException, ClassNotFoundException {
        
       
    try{
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
            stmt=connection.createStatement();
            
        String removedName = oblist.get(EntreeTable.getSelectionModel().getSelectedIndex()).getItem();
			oblist.remove(EntreeTable.getSelectionModel().getSelectedIndex());
			String query = new String("DELETE FROM entree WHERE ITEM_NAME = '"+removedName+"';");
                        stmt.execute(query);
                        DBConnector.getConnection(); 
                    //DBConnector.write(query);
                    messageNotification.deleteSuccessTrayNotification(focus, detail);
        
}   catch (Exception ex) {
        Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
        messageNotification.deleteErrorTrayNotification(focus);
        JOptionPane.showMessageDialog(null, "'"+ModelTable.class.getName()+"' Deleted");
    }
    }

         
     @FXML
     public void deleteMain(ActionEvent event) throws SQLException, ClassNotFoundException{
                
    try{
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
            stmt=connection.createStatement();
            
        String removedName = oblist1.get(MainTable.getSelectionModel().getSelectedIndex()).getItem();
			oblist1.remove(MainTable.getSelectionModel().getSelectedIndex());
			String query = new String("DELETE FROM main WHERE item_name = '"+removedName+"';");
                        stmt.execute(query);
                        DBConnector.getConnection(); 
                    //DBConnector.write(query);
        messageNotification.deleteSuccessTrayNotification(focus, detail);
}   catch (Exception ex) {
        Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
         messageNotification.deleteErrorTrayNotification(focus);
        JOptionPane.showMessageDialog(null, "'"+ModelTable.class.getName()+"'  Deleted");
    }
    }
     
     
     @FXML
     public void deleteDessert(ActionEvent event) throws SQLException, ClassNotFoundException{ 
         
         
    try{
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
            stmt=connection.createStatement();
            
        String removedName = oblist2.get(DessertTable.getSelectionModel().getSelectedIndex()).getItem();
			oblist2.remove(DessertTable.getSelectionModel().getSelectedIndex());
			String query = new String("DELETE FROM dessert WHERE item_name = '"+removedName+"';");
                        stmt.execute(query);
                        DBConnector.getConnection(); 
                    //DBConnector.write(query);
        messageNotification.deleteSuccessTrayNotification(focus, detail);
}   catch (Exception ex) {
        Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
         messageNotification.deleteErrorTrayNotification(focus);
        JOptionPane.showMessageDialog(null, "Deleted");
    }
    }

    
    
//     private ModelTable createSalesDataFromGuiFields() {
//        //only extract id from combo box selection      
//        String Item = EntreeNameField.getText().toString();
//        Double Price = Double.parseDouble(EntreePriceField.getText());
//       // Long Id = Long.parseLong(EntreeIDField.getText());
//        Integer Time = Integer.parseInt(EntreeTimeField.getText());
//        
//        String Item1 = MainNameField.getText().toString();
//        Double Price1 = Double.parseDouble(MainPriceField.getText());
//        //Long Id1 = Long.parseLong(MainIdField.getText());
//        Integer Time1 = Integer.parseInt(MainTimeField.getText());
//        
//        String Item2 = DessertNameField.getText().toString();
//        Double Price2 = Double.parseDouble(DessertPriceField.getText());
//        //Long Id2 = Long.parseLong(DessertIdField.getText());
//        Integer Time2 = Integer.parseInt(DessertTimeField.getText());
//        
//        
//        
//        //sets data to ObservableList based on columns from database
//        ModelTable item = new ModelTable();
//        item.setItem(Item);
//        item.setPrice(Price);
//       // item.setId(Id);
//        item.setTime(Time);
//        
//        item.setItem(Item1);
//        item.setPrice(Price1);
//       // item.setId(Id1);
//        item.setTime(Time1);
//        
//        item.setItem(Item2);
//        item.setPrice(Price2);
//       // item.setId(Id2);
//        item.setTime(Time2);
//        
//       return item;
//    }

    
    
    @FXML
    public void clearMain(){
        MainNameField.setText("");
        MainTimeField.setText("");
        MainPriceField.setText("");
        MainIDField.setText("");
        addButton2.setDisable(false);
        deleteButton2.setDisable(false);
        
    }
    
     
    @FXML
    public void clearEntree(){
        EntreeNameField.setText("");
        EntreeIDField.setText("");
        EntreeTimeField.setText("");
        EntreePriceField.setText("");
        addButton3.setDisable(false);
        deleteButton3.setDisable(false);
    }
    
    @FXML
    public void clearDessert(){
        DessertNameField.setText("");
        DessertIDField.setText("");
        DessertTimeField.setText("");
        DessertPriceField.setText("");
        addButton1.setDisable(false);
        deleteButton1.setDisable(false);
    }

    
    private void populateItems(ObservableList<ModelTable> items) throws ClassNotFoundException {
        //Set items to the salesDataTable
        EntreeTable.setItems(items);
         MainTable.setItems(items);
          DessertTable.setItems(items);
    }

    //fill up gui text fields via table selection of user
    private void selectTableRowSetGuiTextFields() {
          EntreeNameField.setText(EntreeTable.getItems().get(EntreeTable.getSelectionModel().getSelectedIndex()).getItem());
        EntreePriceField.setText(EntreeTable.getItems().get(EntreeTable.getSelectionModel().getSelectedIndex()).getPrice().toString());
    MainNameField.setText(MainTable.getItems().get(MainTable.getSelectionModel().getSelectedIndex()).getItem());
        MainPriceField.setText(MainTable.getItems().get(MainTable.getSelectionModel().getSelectedIndex()).getPrice().toString());
        DessertNameField.setText(DessertTable.getItems().get(DessertTable.getSelectionModel().getSelectedIndex()).getItem());
        DessertPriceField.setText(DessertTable.getItems().get(DessertTable.getSelectionModel().getSelectedIndex()).getPrice().toString());
            
    }

    

    //if empty set gui text fields null or 0
    private void setDefaultGuiTextFields() {
        

        if (EntreeNameField.getText() == null || EntreeNameField.getText().trim().isEmpty()) {
            EntreeNameField.setText("Item Name !");
        }

        if (EntreePriceField.getText() == null || EntreePriceField.getText().trim().isEmpty()) {
            EntreePriceField.setText("0.0");
        }
        if (MainNameField.getText() == null || MainNameField.getText().trim().isEmpty()) {
            MainNameField.setText("Item Name !");
        }

        if (MainPriceField.getText() == null || MainPriceField.getText().trim().isEmpty()) {
            MainPriceField.setText("0.0");
        }
         if (DessertNameField.getText() == null || DessertNameField.getText().trim().isEmpty()) {
            DessertNameField.setText("Item Name !");
        }

        if (DessertPriceField.getText() == null || DessertPriceField.getText().trim().isEmpty()) {
            DessertPriceField.setText("0.0");
        }

    }

    private void resetFields() {
        //EntreePriceField.setText("");
        //EntreePriceField.setText("");
        
        
    }

    @FXML
    private void updateMain(ActionEvent event) throws Exception {
//        ModelTable mt = new ModelTable();
        
        
       try{
        //Connection con = DBConnector.getConnection();
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
                
            stmt=con.createStatement();
            
//            String query = "UPDATE menu.main SET ID = '"+ Integer.parseInt(MainIDField.getText()) +"' item_name = '"+MainNameField.getText()+"' Price = '"+Double.parseDouble(MainPriceField.getText())+"' time_req = '"+Integer.parseInt(MainTimeField.getText())+"'";
//            
//            stmt.executeUpdate(query);


int mainID = Integer.parseInt(MainIDField.getText());
String mainName = MainNameField.getText();


Double mainPrice = Double.parseDouble(MainPriceField.getText());
int mainTime = Integer.parseInt(MainTimeField.getText());


            
              stmt.execute("UPDATE  main  set item_name = '"+mainName+"', price = "+mainPrice+", time_req = "+mainTime+" WHERE ID="+mainID+"");
             //stmt.execute("UPDATE  main (  id = '"+MainIdField.getText() +"',item_name ='"+MainNameField.getText()+"',price = '"+MainPriceField.getText()+"',time_req ='"+MainTimeField.getText()+"')WHERE "
                    // + "id = '"+MainIdField.getText() +"')");
             oblist1.remove(MainTable.getSelectionModel().getSelectedIndex());
             oblist1.add(new ModelTable(Long.parseLong(MainIDField.getText()),MainNameField.getText(), Double.parseDouble(MainPriceField.getText()),Integer.parseInt(MainTimeField.getText())));
             MainTable.getSortOrder().setAll(MId);
             clearMain();
             stmt.close();
//              
              JOptionPane.showMessageDialog(null, "Updated ");
         } catch (SQLException ex) {
            //Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
        }
       catch (Exception e){
           JOptionPane.showMessageDialog(null,"Invalid Input");
       }
    }
       
       
       @FXML
       private void updateEntree(ActionEvent event) throws Exception {
//        ModelTable mt = new ModelTable();
        
        
       try{
        //Connection con = DBConnector.getConnection();
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
                
            stmt=con.createStatement();
            
//            String query = "UPDATE menu.main SET ID = '"+ Integer.parseInt(MainIDField.getText()) +"' item_name = '"+MainNameField.getText()+"' Price = '"+Double.parseDouble(MainPriceField.getText())+"' time_req = '"+Integer.parseInt(MainTimeField.getText())+"'";
//            
//            stmt.executeUpdate(query);
int entreeID = Integer.parseInt(EntreeIDField.getText());
String entreeName = EntreeNameField.getText();
Double entreePrice = Double.parseDouble(EntreePriceField.getText());
int entreeTime = Integer.parseInt(EntreeTimeField.getText());
            
              stmt.execute("UPDATE  entree  set item_name = '"+entreeName+"', price = "+entreePrice+", time_req = "+entreeTime+" WHERE ID="+entreeID+"");
             //stmt.execute("UPDATE  main (  id = '"+MainIdField.getText() +"',item_name ='"+MainNameField.getText()+"',price = '"+MainPriceField.getText()+"',time_req ='"+MainTimeField.getText()+"')WHERE "
                    // + "id = '"+MainIdField.getText() +"')");
             oblist.remove(EntreeTable.getSelectionModel().getSelectedIndex());
             oblist.add(new ModelTable(Long.parseLong(EntreeIDField.getText()),EntreeNameField.getText(), Double.parseDouble(EntreePriceField.getText()),Integer.parseInt(EntreeTimeField.getText())));
             EntreeTable.getSortOrder().setAll(EId);
             clearEntree();
             stmt.close();
//              
              JOptionPane.showMessageDialog(null, "Updated ");
         } catch (SQLException ex) {
            //Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
        }   
       catch (Exception e){
           JOptionPane.showMessageDialog(null,"Invalid Input");
       }
    }
       
       
              
       @FXML
       private void updateDessert(ActionEvent event) throws Exception {
//        ModelTable mt = new ModelTable();
        
        
       try{
        //Connection con = DBConnector.getConnection();
         Connection con = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
                
            stmt=con.createStatement();
            
//            String query = "UPDATE menu.main SET ID = '"+ Integer.parseInt(MainIDField.getText()) +"' item_name = '"+MainNameField.getText()+"' Price = '"+Double.parseDouble(MainPriceField.getText())+"' time_req = '"+Integer.parseInt(MainTimeField.getText())+"'";
//            
//            stmt.executeUpdate(query);
int dessertID = Integer.parseInt(DessertIDField.getText());
String dessertName = DessertNameField.getText();
Double dessertPrice = Double.parseDouble(DessertPriceField.getText());
int dessertTime = Integer.parseInt(DessertTimeField.getText());
            
              stmt.execute("UPDATE  dessert  set item_name = '"+dessertName+"', price = "+dessertPrice+", time_req = "+dessertTime+" WHERE ID="+dessertID+"");
             //stmt.execute("UPDATE  main (  id = '"+MainIdField.getText() +"',item_name ='"+MainNameField.getText()+"',price = '"+MainPriceField.getText()+"',time_req ='"+MainTimeField.getText()+"')WHERE "
                    // + "id = '"+MainIdField.getText() +"')");
             
             oblist2.remove(DessertTable.getSelectionModel().getSelectedIndex());
             oblist2.add(new ModelTable(Long.parseLong(DessertIDField.getText()),DessertNameField.getText(), Double.parseDouble(DessertPriceField.getText()),Integer.parseInt(DessertTimeField.getText())));
             DessertTable.getSortOrder().setAll(DId);
             clearDessert();
             DessertTable.requestFocus();
             
             
             stmt.close();              
              JOptionPane.showMessageDialog(null, "Updated ");
         } catch (SQLException ex) {
            //Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
        }   
       catch (Exception e){
           JOptionPane.showMessageDialog(null,"Invalid Input");
       }
    }

   

    @FXML
    private void backToStaff(ActionEvent event) {
        
        Parent root1;
        try {
            root1 = FXMLLoader.load(getClass().getResource("Staff.fxml"));
            Scene scene = new Scene(root1,700,500);
            Stage stage1 = new Stage();
            stage1.setScene(scene);
            stage1.show();
            stage1.setMaximized(true);
            // Hide this current window (if this is what you want)
            ((Node)(event.getSource())).getScene().getWindow().hide();
            
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    @FXML
    private void exit(ActionEvent event) {
         System.exit(0);
    }

    
        
        
    }