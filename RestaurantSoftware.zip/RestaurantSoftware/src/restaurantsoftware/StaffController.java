    package restaurantsoftware;

import java.io.IOException;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import static restaurantsoftware.DBConnector.stmt;

/**
 * FXML Controller class
 *
 * @author kiran_000
 */
public class StaffController implements Initializable {

    @FXML
    private Button EditMenu;
    
    @FXML
    private Button DeleteOrder;
    @FXML
    private Button Logout;
    @FXML
    private Button ViewHomePage;
    ObservableList<ModelTable> oblist3 = FXCollections.observableArrayList();
    @FXML
    private TableView <ModelTable> cartTable;
     @FXML
    private TableColumn <ModelTable,String> itemColumn;
    @FXML
    private TableColumn <ModelTable,String> priceColumn;
    @FXML
    private TableColumn<ModelTable, String> idColumn;
    @FXML
    private TableColumn<ModelTable, String> timeColumn;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    
    @FXML
    private void billPaid(ActionEvent event) throws SQLException{
        try{
        Connection c = DBConnector.getConnection();
         ResultSet rs = c.createStatement().executeQuery("select * from ordertable WHERE TableNo = ('"+ModelTable.getTableNumber()+"') AND Status=('unpaid')") ;
           
            //ResultSet rs = con.createStatement().executeQuery("select * from cart");
            if (rs.next()){
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
            
            stmt=con.createStatement();
            stmt.execute ("UPDATE ordertable SET Status='paid' WHERE TableNo = '"+ModelTable.getTableNumber()+"'");
            JOptionPane.showMessageDialog(null, "Bill Payment Updated for table "+ModelTable.getTableNumber());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Bill Payment Not Updated");
        } catch (UnknownHostException ex) {
            JOptionPane.showMessageDialog(null, "Bill Payment Not Updated");
        } catch (SocketException ex) {
            JOptionPane.showMessageDialog(null, "Bill Payment Not Updated");
        }
            }else{
                JOptionPane.showMessageDialog(null,"No items have been ordered");
            }
        }catch(Exception e){
            
        }
        }
        
//    
////    public void refreshTable() throws UnknownHostException, SocketException{
////        oblist3.clear();
////        try{
////        Connection con = DBConnector.getConnection();
////            ResultSet rs = con.createStatement().executeQuery("select * from cart WHERE TableNo = ('"+ModelTable.getTableNumber()+"')");
////            while (rs.next()){
////                 oblist3.add(new ModelTable(rs.getLong("Id"),rs.getString("Item"),rs.getDouble("Price"),rs.getInt("Time")));
////            }
////    }   catch (SQLException ex) {
////            Logger.getLogger(ViewCartController.class.getName()).log(Level.SEVERE, null, ex);
////        }
////        cartTable.setItems(oblist3);
////}
//    
    
    @FXML
    private void editOrder (ActionEvent event) throws UnknownHostException, SQLException{
        
       try{
        Connection c = DBConnector.getConnection();
         ResultSet rs = c.createStatement().executeQuery("select * from ordertable WHERE TableNo = ('"+ModelTable.getTableNumber()+"') AND Status=('unpaid')") ;
           
            //ResultSet rs = con.createStatement().executeQuery("select * from cart");
            if (rs.next()){
        try{
            Parent root;
            try{
                root = FXMLLoader.load(getClass().getResource("EditOrder.fxml"));
                Stage stage = new Stage();
                stage.setTitle("Edit Order");
                stage.setScene(new Scene(root));
                stage.show();
                stage.setMaximized(true);
                ((Node)(event.getSource())).getScene().getWindow().hide();
            }
            catch (Exception e){
                e.printStackTrace();
            }
//            Connection con = DBConnector.getConnection();
            
            stmt.execute ("INSERT INTO cart(ITEM,PRICE,TIME,TableNo) SELECT ITEM,PRICE,TIME,TableNo FROM ordertable WHERE TableNo = ('"+ModelTable.getTableNumber()+"') AND Status=('unpaid')") ;
            stmt.execute("DELETE FROM ordertable WHERE TableNo = ('"+ModelTable.getTableNumber()+"') AND Status = 'unpaid'");
            
            //   refreshTable();3)
        } catch (SQLException ex) {
            Logger.getLogger(StaffController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SocketException ex) {
            Logger.getLogger(StaffController.class.getName()).log(Level.SEVERE, null, ex);
        }     
        JOptionPane.showMessageDialog(null, "The order has been reset. You can edit the cart and place new order");    
    }
            else{
                JOptionPane.showMessageDialog(null, "No items have been ordered");
            }
       }catch (Exception ex){
           Logger.getLogger(StaffController.class.getName()).log(Level.SEVERE, null, ex);
       }
            
            }
            
     
      
      


    @FXML
    private void editMenu(ActionEvent event) {
        Parent root1;
        try {
            root1 = FXMLLoader.load(getClass().getResource("EditMenu.fxml"));
            Stage stage1 = new Stage();
            stage1.setTitle("Edit Menu");
            stage1.setScene(new Scene(root1, 1200, 800));
            stage1.show();
            stage1.setMaximized(true);
            // Hide this current window (if this is what you want)
            ((Node)(event.getSource())).getScene().getWindow().hide();
            
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void deleteOrder(ActionEvent event) {
    }

    @FXML
    private void logout(ActionEvent event) {
         System.exit(0);
    }

    private void changePassword(ActionEvent event) {
        
        Parent root1;
        try {
            root1 = FXMLLoader.load(getClass().getResource("Password.fxml"));
            Stage stage1 = new Stage();
            stage1.setTitle("My New Stage Title");
            stage1.setScene(new Scene(root1, 700, 600));
            stage1.show();
            stage1.setMaximized(true);
            // Hide this current window (if this is what you want)
            ((Node)(event.getSource())).getScene().getWindow().hide();
            
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void viewHomePage(ActionEvent event) {
        Parent root1;
        try {
            root1 = FXMLLoader.load(getClass().getResource("FXMLDocument_1.fxml"));
            Stage stage1 = new Stage();
            stage1.setTitle("My New Stage Title");
            stage1.setScene(new Scene(root1, 1200, 800));
            stage1.show();
            stage1.setMaximized(true);
            // Hide this current window (if this is what you want)
            ((Node)(event.getSource())).getScene().getWindow().hide();
            
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
}