/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurantsoftware;

import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Josar
 */
public class BillController implements Initializable {

    @FXML
    private TableView<ModelTable> billTable;
    @FXML
    private TableColumn<ModelTable, String> bitem;
    @FXML
    private TableColumn<ModelTable, Integer> bprice;
    @FXML
    private TextField total;
    @FXML
    private TextField gstField;
    @FXML
    private TextField grandtotalField;
    
    ObservableList<ModelTable> oblist3 = FXCollections.observableArrayList();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try{
            try{
                Connection con = DBConnector.getConnection();
                ResultSet rs = con.createStatement().executeQuery("select Item,Price from ordertable WHERE TableNo = ('"+ModelTable.getTableNumber()+"')") ;
                //ResultSet rs = con.createStatement().executeQuery("select * from cart");
                if (rs.next()){
                    while (rs.next()){
                        oblist3.add(new ModelTable(rs.getString("Item"),rs.getDouble("Price")));
                    }
                    billTable.setItems(oblist3);
                    
                }
            }   catch (SQLException | UnknownHostException | SocketException ex) {
                Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
            }
            bitem.setCellValueFactory(new PropertyValueFactory<>("item"));
            bprice.setCellValueFactory(new PropertyValueFactory<>("price"));
            double totalprice = 0;
            Connection con = DBConnector.getConnection();
             ResultSet rs = con.createStatement().executeQuery ("SELECT SUM(Price) from ordertable WHERE TableNo = ('"+ModelTable.getTableNumber()+"')");
             int index = 1;
             
             while(rs.next()){
                 totalprice = rs.getInt(1);
             }
             
             double gst = Math.round(0.1*totalprice);
             double grandtotal = gst + totalprice;
             
             total.setText("$"+String.valueOf(totalprice));
             gstField.setText("$"+String.valueOf(gst));
             grandtotalField.setText("$"+String.valueOf(grandtotal));
            
        }   catch (SQLException ex) {
            Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnknownHostException ex) {
            Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SocketException ex) {
            Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
        }    
        
    }
    
}