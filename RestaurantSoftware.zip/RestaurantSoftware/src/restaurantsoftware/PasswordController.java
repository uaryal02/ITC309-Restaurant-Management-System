//package restaurantsoftware;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Node;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.control.TextField;
//import javafx.stage.Stage;
//import javax.swing.JOptionPane;
//import static restaurantsoftware.DBConnector.stmt;
//
///**
// *
// * @author kiran_000
// */
//public class PasswordController {
//
//    @FXML
//    private Button ChangePassword;
//    @FXML
//    private TextField newpassword;
//    
//    
//    
//     Stage dialogStage = new Stage();
//    Scene scene;
//
//    Connection connection = null;
//    PreparedStatement preparedStatement = null;
//    ResultSet resultSet = null;
//    @FXML
//    private TextField username;
//
////    @FXML
////    private void changePassword(ActionEvent event) {
////        String Username = username.getText().toString();
////         String Password = newpassword.getText().toString();
////         
////       try {
////           newpassword.setText(null);
////       
////        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
////        stmt=connection.createStatement();
////        stmt.execute("UPDATE staff SET password = '"+newpassword+"'");
////        stmt.close();
////        JOptionPane.showMessageDialog(null, "Password Updated");
////        if (!resultSet.next()) {
////            //System.out.println"Enter Correct Email and Password", "Failed", null;
////        } else {
////          //  infoBox("Login Successfull", "Success", null);
////            
////        }
////
////    } catch (Exception e) {
////        e.printStackTrace();
////    }
////        
////    }
//
//    
//}
