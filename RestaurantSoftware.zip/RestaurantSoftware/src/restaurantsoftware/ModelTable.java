package restaurantsoftware;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;
import static restaurantsoftware.DBConnector.stmt;



/**
 *
 * @author Josar
 */
public class ModelTable {

    static void insertItem(ModelTable createSalesDataFromGuiFields) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
//    static ObservableList<Item> searchItem() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
String item;

Long id;
Double price;
Integer time, Table_Number;

private Button button;

private Button button1;

private Button button2;
 @FXML
    private TableView<ModelTable> cartTable;


DBConnector db = new DBConnector();
int count = 0;
String number = new String();
TextField textField;
ObservableList<ModelTable> oblist3 = FXCollections.observableArrayList();
ObservableList<ModelTable> oblist4 = FXCollections.observableArrayList();
TableView<ModelTable> view = new TableView<>();

public ModelTable (String item,Double price,Integer time){
    this.item=item;
    this.price=price;
    this.time=time;
    
}

public ModelTable (String item,Double price,Integer time,Integer Table_Number){
    this.item=item;
    this.price=price;
    this.time=time;
    this.Table_Number = Table_Number;
    
}

public ModelTable (Long id, String item, Double price, Integer time){
    this.item = item;
    this.price = price;
    this.id = id;
    this.time = time;
    this.button = new Button("Add To Cart");
    this.button1 = new Button("DELETE");
    this.button2=new Button("DELETE");
    
    
    
    button.setOnAction(evt -> {
        try {
            
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
            stmt=connection.createStatement();
            stmt.execute("CREATE TABLE IF NOT EXISTS cart ( ID BIGINT(45) NOT NULL AUTO_INCREMENT,ITEM VARCHAR(45),PRICE DOUBLE,TIME INTEGER(45), TableNo INT, PRIMARY KEY(ID));");
            stmt.close();
            stmt=connection.createStatement();
            stmt.execute ("INSERT INTO cart(ITEM,PRICE,TIME,TableNo) VALUES ('"+ModelTable.this.getItem()+"','"+ModelTable.this.getPrice()+"','"+ModelTable.this.getTime()+"','"+ModelTable.this.getTableNumber()+"')");
            
            stmt.close();
            stmt=connection.createStatement();
            ResultSet rs = db.stmt.executeQuery("SELECT * FROM cart");
            while (rs.next()){
                count++;
                
            }
            number = Integer.toString(count);
            //textField.setText("100");
            stmt.close();
            
            
            JOptionPane.showMessageDialog(null, "'"+ModelTable.this.getItem()+"' Added to cart ");       
        } catch (SQLException ex) {
            Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
             JOptionPane.showMessageDialog(null, " Not Added ");
        } catch (UnknownHostException ex) {
            Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SocketException ex) {
            Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
        }
        
} );

    
    
    
    button1.setOnAction((ActionEvent evt) -> {
          
           
        
    try{
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
        stmt = connection.createStatement();
       		
        stmt.execute("DELETE FROM cart WHERE ID = ('"+ModelTable.this.getId()+"') AND TableNo = ('"+ModelTable.this.getTableNumber()+"')") ;      
        
        DBConnector.getConnection(); 
         stmt.close();
         
         
//         refreshTable();
         JOptionPane.showMessageDialog(null, "'"+ModelTable.this.getItem()+"' deleted from cart ");
   }   catch (SQLException ex) {
        Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
         JOptionPane.showMessageDialog(null, "Not Deleted ");
    }   catch (UnknownHostException ex) {
            Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SocketException ex) {
            Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    });
    
    button2.setOnAction((ActionEvent evt1) ->{
       try{
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/menu","root","1995");
        stmt = connection.createStatement();
       		
        stmt.execute("DELETE FROM ordertable WHERE ID = ('"+ModelTable.this.getId()+"') AND TableNo = ('"+ModelTable.this.getTableNumber()+"')") ;      
        
       // DBConnector.getConnection(); 
         stmt.close();
//         refreshTable();
         JOptionPane.showMessageDialog(null, "'"+ModelTable.this.getItem()+"' deleted from order ");
   }   catch (SQLException ex) {
        Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
         JOptionPane.showMessageDialog(null, "Not Deleted ");
    }   catch (UnknownHostException ex) {
            Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SocketException ex) {
            Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
        } 
    });


   


   
    
    
    
}

    ModelTable() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    ModelTable(String item, double price) {
        this.item = item;
        this.price = price;
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
     public void refreshTable() throws UnknownHostException, SocketException{
        oblist3.clear();
        try{
        Connection con = DBConnector.getConnection();
            ResultSet rs = con.createStatement().executeQuery("select * from cart where TableNo = ('"+ModelTable.getTableNumber()+"')");
            while (rs.next()){
                 oblist3.add(new ModelTable(rs.getLong("Id"),rs.getString("Item"),rs.getDouble("Price"),rs.getInt("Time")));
            }
    }   catch (SQLException ex) {
            Logger.getLogger(ViewCartController.class.getName()).log(Level.SEVERE, null, ex);
        }
        cartTable.setItems(null);
        cartTable.setItems(oblist3);
}
    
    public static int getTableNumber() throws UnknownHostException, SocketException{
    
        
        
        InetAddress ip;
    int Table_Number=0;
    ip = InetAddress.getLocalHost();
    NetworkInterface network = NetworkInterface.getByInetAddress(ip);
    byte[] mac = network.getHardwareAddress();
    StringBuilder sb = new StringBuilder();
		for (int i = 0; i < mac.length; i++) {
			sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));		
		}
    String MacAddress = sb.toString();
    System.out.println (MacAddress);
//    for (int i=0;i<5;i++){
//    System.out.println(MacAddress);
//    }
try{
        Connection con = DBConnector.getConnection();
            ResultSet rs = con.createStatement().executeQuery("select TableNo from tablee WHERE tablee.MacAddress = '"+MacAddress+"'") ;
            ArrayList < Integer > list = new ArrayList < Integer > ();
            while (rs.next()) {
 list.add(rs.getInt(1));
}
//            for (int i = 1;i<2;i++){
                Table_Number = list.get(0);
//            }
}
catch (SQLException ex) {
            Logger.getLogger(ModelTable.class.getName()).log(Level.SEVERE, null, ex);
        }
       
	return Table_Number;
        
     
    
}    
    
        
    
    
    
public String getItem(){
    return item;
}
public Double getPrice(){
    return price;
}

public Long getId(){
    return id;
}
public Integer getTime(){
    return time;
}


public void setItem(String item){
    this.item = item;
}
public void setPrice(Double price){
    this.price = price;
}

public void setId(Long id){
    this.id = id;
}
public void setTime(Integer time){
    this.time = time;
}

public Button getButton(){
    return button;
}

public Button getButton1(){
    return button1;
}

public Button getButton2(){
    return button2;
}


public String getString(){
    return number;
}
public void setString(String number){
    this.number = number;
}


public void setButton(Button button){
    this.button = button;
}

public void setButton1(Button button1){
    this.button = button1;
}

public void setButton2(Button button2){
    this.button = button2;
}


   
     @Override
    public String toString() {
        return "ModelTable { Id: " + this.id + ",Item: " + this.item + ",  Price: " + this.price + ",Time: " + this.time + "}";
    }
    
    
    
    
}